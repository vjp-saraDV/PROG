/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio06;

/**
 *
 * @author Sara
 */
public class Ejercicio06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //Identificador "descarta2": Es correcto.
       //Identificador "cuántosQuerrás": Es incorrecto porque los identificadores no deben tener tildes.
       //Identificador "çaVaBienAvec$$": Es incorrecto porque los identificadores no deben tener caracteres especiales.
       //Identificador "Êgresa": Es incorrecto porque los identificadores no deben tener caracteres especiales.
       //Identificador "österreich": Es incorrecto porque los identificadores no deben tener caracteres especiales.
       //Identificador "Ñosÿevan": Es incorrecto porque los identificadores no deben tener caracteres especiales.
       //Identificador "EsôÇäépùo9": Es incorrecto porque los identificadores no deben tener caracteres especiales.
    }
    
}
