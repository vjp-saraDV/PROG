/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio5;

/**
 *
 * @author Sara
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int mi carta; //Es incorrecto porque la variable tiene que ir junto o con un "_" entre medias.
        int unacarta; //Es correcto.
        int Mis2escritos; //Es incorrecto porque la primera letra tiene que ser minúscula, aunque no salga error.
        int 4cientos; //Es incorrecto porque la variable siempre tiene que empezar por una letra.
        int es_un_mensaje; //Es correcto.
        int no_vale nada; //Es incorrecto porque entre "vale" y "nada" tendría que haber un "_".
        int ____ejemplo_____; //Es incorrecto porque la variable siempre tiene que empezar por una letra, aunque no salga error.
        int mi-programa; //Es incorrecto porque la varible solo puede estar separada por "_".
        int ¿cuantos?; //Es incorrecto porque la variable solo puede empezar por una letra.
        int el%Descontado; //Es incorrecto porque la varible solo puede estar separada por "_", y no tiene que tener letras mayúsculas.
        int a200PORAÑO; //Es incorrecto porque la variable tiene que estar escrita únicamente en minúsculas, aunque no salga error.
        int TengoMUCHOS$$$; //Es incorrecto porque la variable tiene que estar escrita en minúsuculas, aunque no salga error.
        int LOS400GOLPES; //Es incorrecto porque la variable tiene que estar escrita en minúsuculas, aunque no salga error.
        int quieroUNAsolución; //Es incorrecto porque la variable tiene que estar escrita en minúsuculas, aunque no salga error.
    }
    
}
